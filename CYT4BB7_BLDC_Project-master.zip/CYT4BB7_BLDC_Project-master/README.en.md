# CYT4BB7_BLDC_Project

#### Description
受组委会及英飞凌委托，逐飞科技针对第十九届智能汽车竞赛信标越野组的BLDC应用需求，精心设计了符合赛事需求的CYT4BB7 BLDC驱动开源方案供大家参考，该方案使用CYT4BB7三核芯片，使用TCPWM单元输出电机所需的PWM信号。电机为内转子、3450Kv、电压为12V。开源项目具有的功能，目前支持电机正反转、支持过流保护、支持电池保护、支持自定义换相角、支持外部pwm信号控制电机。

#### Software Architecture
Software architecture description

#### Installation

1.  xxxx
2.  xxxx
3.  xxxx

#### Instructions

1.  xxxx
2.  xxxx
3.  xxxx

#### Contribution

1.  Fork the repository
2.  Create Feat_xxx branch
3.  Commit your code
4.  Create Pull Request


#### Gitee Feature

1.  You can use Readme\_XXX.md to support different languages, such as Readme\_en.md, Readme\_zh.md
2.  Gitee blog [blog.gitee.com](https://blog.gitee.com)
3.  Explore open source project [https://gitee.com/explore](https://gitee.com/explore)
4.  The most valuable open source project [GVP](https://gitee.com/gvp)
5.  The manual of Gitee [https://gitee.com/help](https://gitee.com/help)
6.  The most popular members  [https://gitee.com/gitee-stars/](https://gitee.com/gitee-stars/)
