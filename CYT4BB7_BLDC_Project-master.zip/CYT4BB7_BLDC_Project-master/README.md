# CYT4BB7_BLDC_Project

#### 介绍
受组委会及英飞凌委托，逐飞科技针对第十九届智能汽车竞赛信标越野组的BLDC应用需求，精心设计了符合赛事需求的CYT4BB7 BLDC驱动开源方案供大家参考，该方案使用CYT4BB7三核芯片，使用TCPWM单元输出电机所需的PWM信号。电机为内转子、3450Kv、电压为12V。开源项目具有的功能，目前支持电机正反转、支持过流保护、支持电池保护、支持自定义换相角、支持外部pwm信号控制电机。

#### 软件架构
软件架构说明


#### 安装教程

1.  xxxx
2.  xxxx
3.  xxxx

#### 使用说明

1.  xxxx
2.  xxxx
3.  xxxx

#### 参与贡献

1.  Fork 本仓库
2.  新建 Feat_xxx 分支
3.  提交代码
4.  新建 Pull Request


#### 特技

1.  使用 Readme\_XXX.md 来支持不同的语言，例如 Readme\_en.md, Readme\_zh.md
2.  Gitee 官方博客 [blog.gitee.com](https://blog.gitee.com)
3.  你可以 [https://gitee.com/explore](https://gitee.com/explore) 这个地址来了解 Gitee 上的优秀开源项目
4.  [GVP](https://gitee.com/gvp) 全称是 Gitee 最有价值开源项目，是综合评定出的优秀开源项目
5.  Gitee 官方提供的使用手册 [https://gitee.com/help](https://gitee.com/help)
6.  Gitee 封面人物是一档用来展示 Gitee 会员风采的栏目 [https://gitee.com/gitee-stars/](https://gitee.com/gitee-stars/)
